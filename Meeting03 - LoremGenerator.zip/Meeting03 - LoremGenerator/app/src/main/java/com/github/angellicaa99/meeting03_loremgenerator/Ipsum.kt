package com.github.angellicaa99.meeting03_loremgenerator

data class Ipsum(val type: String, val content: String)